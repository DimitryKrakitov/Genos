from django.http import HttpResponse,Http404
from django.shortcuts import render, get_object_or_404, redirect
from .models import Campus,Building,Floor,Room,Users
from .forms import UserForm
from .serializers import UsersSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.views import APIView

from django.contrib.auth import authenticate, login
from django.views.generic import View

from .fenix import FenixClient
import fenixedu


# Create your views here.
def index(request):
    all_campus = Campus.objects.all()
    #template =loader.get_template('map/index.html')
    context = {
        'all_campus': all_campus,
    }
    """html=''
    for campus in all_campus:
        url = '/map/' + str(campus.id) + '/'
        html += '<a href="' + url + '">' + campus.name + '</a><br>'
    """
    return render(request, 'map/index.html', context)

def campus_show(request, campus_id):
    campus = get_object_or_404(Campus, pk=campus_id)
    context = {
        'object_type': "Building",
        'parent': "campus " + campus.name,
        'objects': campus,
    }

    return render(request,'map/campus_show.html', context)

def building_show(request, campus_id, building_id):
    buildings = get_object_or_404(Building, pk=building_id, campus=campus_id)
    context = {
        'object_type': "Floor",
        'parent': "floor " + buildings.name,
        'objects': buildings,
    }

    return render(request,'map/building_show.html', context)

def floor_show(request, campus_id, building_id, floor_id):
    floors = get_object_or_404(Floor, pk=floor_id, building=building_id)
    context = {
        'object_type': "Room",
        'parent': "room " + floors.name,
        'objects': floors,
    }

    return render(request,'map/floor_show.html', context)

def reserve(request, campus_id, building_id, floor_id):
    floors = get_object_or_404(Floor, pk=floor_id, building=building_id)
    try:
        selected_room = floors.room_set.get(pk=request.POST['room'])
        context = {
            'object_type': "Room",
            'parent': "room " + floors.name,
            'objects': floors,
        }
    except(KeyError, Room.DoesNotExist):
        return render(request, 'map/floor_show.html', {
            'object_type': "Room",
            'parent': "room " + floors.name,
            'objects': floors,
            'error_message': "You did not select a valid room",
        })
    else:
        selected_room.is_reserved = True
        selected_room.save()
        return render(request, 'map/floor_show.html', context)


class UserFormView(View):
    form_class = UserForm
    def get(self, request):
        print("GET")
        code = self.request.get('code')
        print(code)
        user = FenixClient.client.get_user_by_code('%s' % code)
        ### WHAT IF SOMETHING FAILS????
        person = FenixClient.client.get_person(user)

        username = person.get('username')
        name = person.get('displayName')
        user.set_password(code)
        user.save()


        # returns User objects if credentials are correct
        user = authenticate(username=username, name=name, code=code)

        if user is not None:
            if user.is_active: # user is not banned
                login(request, user) #user is not logged in
                return redirect('map:index') # redirect to homepage
                #if you want to print out the user name:
                # request.user.uesrname, request.user.name ... profile picture...

        ### SHOW SUCCESS PAGE AND RETURN TO HOMEPAGE?

        """
        form = self.form_class(request.POST)
        if form.is_valid():
            user = form.save(commit=False)

            # clean (normalized) data
            username = form.cleaned_data['username']
            name = form.cleaned_data['name']
            code = form.cleaned_data['code']
            user.set_password(code)
            user.save() """


    def post(self, request):
        print("POST")
        pass

# Lists all the Users or creates a new user
class UserList(APIView):

    def get(self, request):
        users = Users.objects.all()
        serializer = UsersSerializer(users, many=True)
        return Response(serializer.data) #Json

    def post(self):

        pass
