from django.conf.urls import url
from . import views

app_name = 'map'

urlpatterns = [
    url(r'^$', views.index, name='index'),# /map/

    url(r'^authenticate/$', views.UserFormView, name='UserFormView'),# /map/authenticate/

    url(r'^(?P<campus_id>[0-9]+)/$', views.campus_show, name="campus_show"),# /map/campus_id
    url(r'^(?P<campus_id>[0-9]+)/(?P<building_id>[0-9]+)/$', views.building_show, name="building_show"),# /map/building_id
    url(r'^(?P<campus_id>[0-9]+)/(?P<building_id>[0-9]+)/(?P<floor_id>[0-9]+)/$', views.floor_show, name="floor_show"),# /map/floor_id

    url(r'^(?P<campus_id>[0-9]+)/(?P<building_id>[0-9]+)/(?P<floor_id>[0-9]+)/reserve/$', views.reserve, name="reserve"),# /map/campus_id/reserved/
]
