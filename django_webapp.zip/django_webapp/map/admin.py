from django.contrib import admin
from .models import Campus,Building,Floor,Room, Users

admin.site.register(Campus)
admin.site.register(Building)
admin.site.register(Floor)
admin.site.register(Room)
admin.site.register(Users)
# Register your models here.
