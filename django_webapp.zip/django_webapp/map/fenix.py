import fenixedu

class FenixClient:
    client = []
    url = []

    @staticmethod
    def start_client():
        config = fenixedu.FenixEduConfiguration('288540197912622', 'http://127.0.0.1:8000/map/authenticate/',
                                                '9jk55PGiffGIcEhwMZg2iRSOZ7Ky7fTecFdRWYQfNhaVxDpH4qmkoaEsrQhHZkt2sP5xhgJKHLG/A3Q/9XsVYA==',
                                                'http://127.0.0.1:8000/map/')
        FenixClient.client = fenixedu.FenixEduClient(config)
        FenixClient.url = FenixClient.client.get_authentication_url()
        print(FenixClient.url)