from django.contrib import admin
from django.conf.urls import url, include
from rest_framework.urlpatterns import format_suffix_patterns
from map import views


urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^map/', include('map.urls')),
    url(r'^users/', views.UserList.as_view()),
]

from map.fenix import FenixClient ### Create the Fenix client on startup
FenixClient.start_client()



#### We should populate the map to

urlpatterns = format_suffix_patterns(urlpatterns)